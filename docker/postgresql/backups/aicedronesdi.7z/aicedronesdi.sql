--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5 (Debian 14.5-1.pgdg110+1)
-- Dumped by pg_dump version 15.10 (Debian 15.10-0+deb12u1)

-- Started on 2025-02-07 13:02:01 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 9 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- TOC entry 7 (class 2615 OID 18652)
-- Name: sch_aicedronesdi; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA sch_aicedronesdi;


ALTER SCHEMA sch_aicedronesdi OWNER TO postgres;

--
-- TOC entry 8 (class 2615 OID 18654)
-- Name: sch_viewer; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA sch_viewer;


ALTER SCHEMA sch_viewer OWNER TO postgres;

--
-- TOC entry 2 (class 3079 OID 18655)
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- TOC entry 5658 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- TOC entry 3 (class 3079 OID 19686)
-- Name: pgrouting; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgrouting WITH SCHEMA public;


--
-- TOC entry 5659 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pgrouting; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgrouting IS 'pgRouting Extension';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 222 (class 1259 OID 20245)
-- Name: jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 20250)
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobs_id_seq OWNER TO postgres;

--
-- TOC entry 5660 (class 0 OID 0)
-- Dependencies: 223
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- TOC entry 224 (class 1259 OID 20251)
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 20254)
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO postgres;

--
-- TOC entry 5661 (class 0 OID 0)
-- Dependencies: 225
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- TOC entry 226 (class 1259 OID 20255)
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_permissions OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 20258)
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_roles OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 20261)
-- Name: password_resets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_resets (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_resets OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 20266)
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 20271)
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO postgres;

--
-- TOC entry 5662 (class 0 OID 0)
-- Dependencies: 230
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- TOC entry 231 (class 1259 OID 20272)
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 20277)
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO postgres;

--
-- TOC entry 5663 (class 0 OID 0)
-- Dependencies: 232
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- TOC entry 233 (class 1259 OID 20278)
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.role_has_permissions OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 20281)
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 20286)
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- TOC entry 5664 (class 0 OID 0)
-- Dependencies: 235
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- TOC entry 236 (class 1259 OID 20287)
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 20292)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 238 (class 1259 OID 20297)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- TOC entry 5665 (class 0 OID 0)
-- Dependencies: 238
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 239 (class 1259 OID 20298)
-- Name: job; Type: TABLE; Schema: sch_aicedronesdi; Owner: postgres
--

CREATE TABLE sch_aicedronesdi.job (
    id bigint NOT NULL,
    id_proyecto bigint NOT NULL,
    nombre text,
    mensaje text,
    estado text DEFAULT 'Pendiente'::text NOT NULL,
    notificado boolean DEFAULT false NOT NULL,
    fechahora timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE sch_aicedronesdi.job OWNER TO postgres;

--
-- TOC entry 240 (class 1259 OID 20306)
-- Name: project; Type: TABLE; Schema: sch_aicedronesdi; Owner: postgres
--

CREATE TABLE sch_aicedronesdi.project (
    id bigint NOT NULL,
    nombre text,
    inicio date,
    fin date,
    estado text NOT NULL,
    geom public.geometry(Polygon,4326),
    id_usuario integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    workspace text
);


ALTER TABLE sch_aicedronesdi.project OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 20311)
-- Name: proyecto_id_seq; Type: SEQUENCE; Schema: sch_aicedronesdi; Owner: postgres
--

CREATE SEQUENCE sch_aicedronesdi.proyecto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sch_aicedronesdi.proyecto_id_seq OWNER TO postgres;

--
-- TOC entry 5666 (class 0 OID 0)
-- Dependencies: 241
-- Name: proyecto_id_seq; Type: SEQUENCE OWNED BY; Schema: sch_aicedronesdi; Owner: postgres
--

ALTER SEQUENCE sch_aicedronesdi.proyecto_id_seq OWNED BY sch_aicedronesdi.project.id;


--
-- TOC entry 242 (class 1259 OID 20312)
-- Name: tasks; Type: TABLE; Schema: sch_aicedronesdi; Owner: postgres
--

CREATE TABLE sch_aicedronesdi.tasks (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name text NOT NULL,
    message text NOT NULL,
    state text DEFAULT 'Pending'::text NOT NULL,
    notified boolean DEFAULT false NOT NULL,
    type text NOT NULL,
    command text NOT NULL,
    condition text,
    datetime timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE sch_aicedronesdi.tasks OWNER TO postgres;

--
-- TOC entry 243 (class 1259 OID 20320)
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: sch_aicedronesdi; Owner: postgres
--

CREATE SEQUENCE sch_aicedronesdi.tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sch_aicedronesdi.tasks_id_seq OWNER TO postgres;

--
-- TOC entry 5667 (class 0 OID 0)
-- Dependencies: 243
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: sch_aicedronesdi; Owner: postgres
--

ALTER SEQUENCE sch_aicedronesdi.tasks_id_seq OWNED BY sch_aicedronesdi.tasks.id;


--
-- TOC entry 244 (class 1259 OID 20321)
-- Name: trabajo_id_seq; Type: SEQUENCE; Schema: sch_aicedronesdi; Owner: postgres
--

CREATE SEQUENCE sch_aicedronesdi.trabajo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sch_aicedronesdi.trabajo_id_seq OWNER TO postgres;

--
-- TOC entry 5668 (class 0 OID 0)
-- Dependencies: 244
-- Name: trabajo_id_seq; Type: SEQUENCE OWNED BY; Schema: sch_aicedronesdi; Owner: postgres
--

ALTER SEQUENCE sch_aicedronesdi.trabajo_id_seq OWNED BY sch_aicedronesdi.job.id;


--
-- TOC entry 245 (class 1259 OID 20334)
-- Name: capas_id_seq; Type: SEQUENCE; Schema: sch_viewer; Owner: postgres
--

CREATE SEQUENCE sch_viewer.capas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sch_viewer.capas_id_seq OWNER TO postgres;

--
-- TOC entry 246 (class 1259 OID 20335)
-- Name: groups; Type: TABLE; Schema: sch_viewer; Owner: postgres
--

CREATE TABLE sch_viewer.groups (
    id integer NOT NULL,
    nombre character varying(256) NOT NULL,
    descripcion character varying(1024),
    visible boolean DEFAULT true NOT NULL,
    posicion integer,
    min_zoom numeric DEFAULT 12,
    max_zoom numeric DEFAULT 28,
    grupo_sistema boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE sch_viewer.groups OWNER TO postgres;

--
-- TOC entry 247 (class 1259 OID 20345)
-- Name: grupo_simbologia_id_seq; Type: SEQUENCE; Schema: sch_viewer; Owner: postgres
--

CREATE SEQUENCE sch_viewer.grupo_simbologia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sch_viewer.grupo_simbologia_id_seq OWNER TO postgres;

--
-- TOC entry 248 (class 1259 OID 20346)
-- Name: grupos_id_seq; Type: SEQUENCE; Schema: sch_viewer; Owner: postgres
--

CREATE SEQUENCE sch_viewer.grupos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sch_viewer.grupos_id_seq OWNER TO postgres;

--
-- TOC entry 5669 (class 0 OID 0)
-- Dependencies: 248
-- Name: grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: sch_viewer; Owner: postgres
--

ALTER SEQUENCE sch_viewer.grupos_id_seq OWNED BY sch_viewer.groups.id;


--
-- TOC entry 249 (class 1259 OID 20347)
-- Name: layers; Type: TABLE; Schema: sch_viewer; Owner: postgres
--

CREATE TABLE sch_viewer.layers (
    id integer DEFAULT nextval('sch_viewer.capas_id_seq'::regclass) NOT NULL,
    id_grupo integer NOT NULL,
    titulo character varying(256) NOT NULL,
    workspace character varying(512) NOT NULL,
    name character varying(512) NOT NULL,
    style character varying(512),
    visible boolean DEFAULT false NOT NULL,
    posicion integer DEFAULT 1,
    queryable boolean DEFAULT true,
    origen character varying(10),
    min_zoom numeric DEFAULT 12,
    max_zoom numeric DEFAULT 28,
    capa_sistema boolean DEFAULT false,
    publica boolean DEFAULT false,
    displayinlayerswitcher boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    activa boolean DEFAULT true NOT NULL,
    descargable boolean DEFAULT false NOT NULL,
    tipo text DEFAULT 'wmts'::text NOT NULL,
    leyenda text,
    baselayer boolean DEFAULT false NOT NULL,
    preview text
);


ALTER TABLE sch_viewer.layers OWNER TO postgres;

--
-- TOC entry 250 (class 1259 OID 20366)
-- Name: simbologia_id_seq; Type: SEQUENCE; Schema: sch_viewer; Owner: postgres
--

CREATE SEQUENCE sch_viewer.simbologia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sch_viewer.simbologia_id_seq OWNER TO postgres;

--
-- TOC entry 5388 (class 2604 OID 20389)
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- TOC entry 5389 (class 2604 OID 20390)
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- TOC entry 5390 (class 2604 OID 20391)
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- TOC entry 5391 (class 2604 OID 20392)
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- TOC entry 5392 (class 2604 OID 20393)
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- TOC entry 5393 (class 2604 OID 20394)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 5394 (class 2604 OID 20395)
-- Name: job id; Type: DEFAULT; Schema: sch_aicedronesdi; Owner: postgres
--

ALTER TABLE ONLY sch_aicedronesdi.job ALTER COLUMN id SET DEFAULT nextval('sch_aicedronesdi.trabajo_id_seq'::regclass);


--
-- TOC entry 5398 (class 2604 OID 20396)
-- Name: project id; Type: DEFAULT; Schema: sch_aicedronesdi; Owner: postgres
--

ALTER TABLE ONLY sch_aicedronesdi.project ALTER COLUMN id SET DEFAULT nextval('sch_aicedronesdi.proyecto_id_seq'::regclass);


--
-- TOC entry 5399 (class 2604 OID 20397)
-- Name: tasks id; Type: DEFAULT; Schema: sch_aicedronesdi; Owner: postgres
--

ALTER TABLE ONLY sch_aicedronesdi.tasks ALTER COLUMN id SET DEFAULT nextval('sch_aicedronesdi.tasks_id_seq'::regclass);


--
-- TOC entry 5403 (class 2604 OID 20400)
-- Name: groups id; Type: DEFAULT; Schema: sch_viewer; Owner: postgres
--

ALTER TABLE ONLY sch_viewer.groups ALTER COLUMN id SET DEFAULT nextval('sch_viewer.grupos_id_seq'::regclass);


--
-- TOC entry 5623 (class 0 OID 20245)
-- Dependencies: 222
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- TOC entry 5625 (class 0 OID 20251)
-- Dependencies: 224
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_resets_table	1
3	2019_08_19_000000_create_failed_jobs_table	1
4	2019_12_14_000001_create_personal_access_tokens_table	1
5	2022_06_27_072607_create_sessions_table	1
6	2022_06_27_073119_create_permission_tables	1
59	2022_08_05_094714_create_jobs_table	2
60	2022_10_13_075023_create_jobs_table	3
\.


--
-- TOC entry 5627 (class 0 OID 20255)
-- Dependencies: 226
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_has_permissions (permission_id, model_type, model_id) FROM stdin;
\.


--
-- TOC entry 5628 (class 0 OID 20258)
-- Dependencies: 227
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_has_roles (role_id, model_type, model_id) FROM stdin;
1	App\\Models\\User	20
1	App\\Models\\User	22
1	App\\Models\\User	23
1	App\\Models\\User	21
3	App\\Models\\User	25
1	App\\Models\\User	26
1	App\\Models\\User	27
\.


--
-- TOC entry 5629 (class 0 OID 20261)
-- Dependencies: 228
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_resets (email, token, created_at) FROM stdin;
juanramon.charco@uclm.es	$2y$10$eQgA.8HUbbHfYSApERWoiuZCMLm1Xa54mkHdVcQ9HzXwFDpvee/Bq	2022-10-31 10:36:54
\.


--
-- TOC entry 5630 (class 0 OID 20266)
-- Dependencies: 229
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM stdin;
2	Gestor de archivos	web	2022-11-07 11:35:23	2022-11-07 11:35:23
1	Usuarios	web	2022-07-11 08:10:15	2022-12-04 14:57:36
4	Proyectos	web	2022-12-04 15:03:16	2023-07-14 09:08:32
\.


--
-- TOC entry 5632 (class 0 OID 20272)
-- Dependencies: 231
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, created_at, updated_at) FROM stdin;
1	App\\Models\\User	1	LaravelSanctumAuth	c016635452b58cf207e8115017d5e87cec02b08e39c0eb6004827d3332059e23	["*"]	\N	2022-06-28 06:51:26	2022-06-28 06:51:26
\.


--
-- TOC entry 5634 (class 0 OID 20278)
-- Dependencies: 233
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_has_permissions (permission_id, role_id) FROM stdin;
2	1
1	1
4	1
2	3
4	3
\.


--
-- TOC entry 5635 (class 0 OID 20281)
-- Dependencies: 234
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, guard_name, created_at, updated_at) FROM stdin;
1	Administrador	web	2022-07-11 08:13:04	2022-07-11 08:13:04
3	Usuario	web	2024-08-02 07:13:51	2024-08-02 07:13:51
\.


--
-- TOC entry 5637 (class 0 OID 20287)
-- Dependencies: 236
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
VGL7lHDAfA5FQRWrJ7pdiXNW4We34mvCPAX2bHie	27	192.168.18.88	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0	YTo2OntzOjY6Il90b2tlbiI7czo0MDoiUXhDY2FpaEdVaHpVekhjUlo2TUNYTXU3T1k5N0w1SnBwUWZDVDh3UyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjMxOiJodHRwOi8vMTkyLjE2OC4xOC4xNDkvcHJveWVjdG9zIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mjc7czo0OiJhdXRoIjthOjE6e3M6MjE6InBhc3N3b3JkX2NvbmZpcm1lZF9hdCI7aToxNzM4OTMzMjg2O319	1738933303
\.


--
-- TOC entry 5387 (class 0 OID 18965)
-- Dependencies: 218
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- TOC entry 5638 (class 0 OID 20292)
-- Dependencies: 237
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at) FROM stdin;
27	Administrador	admin@admin.com	\N	$2y$10$R4GmTpmzS2OTu3IuPV/xWuAXdhRIhASF8TLKA1nox18q8cicUnd.q	\N	2025-02-07 13:01:04	2025-02-07 13:01:04
\.


--
-- TOC entry 5640 (class 0 OID 20298)
-- Dependencies: 239
-- Data for Name: job; Type: TABLE DATA; Schema: sch_aicedronesdi; Owner: postgres
--

COPY sch_aicedronesdi.job (id, id_proyecto, nombre, mensaje, estado, notificado, fechahora) FROM stdin;
\.


--
-- TOC entry 5641 (class 0 OID 20306)
-- Dependencies: 240
-- Data for Name: project; Type: TABLE DATA; Schema: sch_aicedronesdi; Owner: postgres
--

COPY sch_aicedronesdi.project (id, nombre, inicio, fin, estado, geom, id_usuario, created_at, updated_at, workspace) FROM stdin;
\.


--
-- TOC entry 5643 (class 0 OID 20312)
-- Dependencies: 242
-- Data for Name: tasks; Type: TABLE DATA; Schema: sch_aicedronesdi; Owner: postgres
--

COPY sch_aicedronesdi.tasks (id, project_id, name, message, state, notified, type, command, condition, datetime) FROM stdin;
\.


--
-- TOC entry 5647 (class 0 OID 20335)
-- Dependencies: 246
-- Data for Name: groups; Type: TABLE DATA; Schema: sch_viewer; Owner: postgres
--

COPY sch_viewer.groups (id, nombre, descripcion, visible, posicion, min_zoom, max_zoom, grupo_sistema, created_at, updated_at) FROM stdin;
1	Mapas Base	\N	t	999999999	0	28	t	2023-03-20 15:32:58.354088	\N
\.


--
-- TOC entry 5650 (class 0 OID 20347)
-- Dependencies: 249
-- Data for Name: layers; Type: TABLE DATA; Schema: sch_viewer; Owner: postgres
--

COPY sch_viewer.layers (id, id_grupo, titulo, workspace, name, style, visible, posicion, queryable, origen, min_zoom, max_zoom, capa_sistema, publica, displayinlayerswitcher, created_at, updated_at, activa, descargable, tipo, leyenda, baselayer, preview) FROM stdin;
10	1	empty_layer	aicedronesdi	empty_layer	\N	t	6	f	wms	0	28	t	t	f	2023-08-15 18:16:08.799533	\N	t	f	wms	\N	f	\N
14	1	Fondo PNOA	aicedronesdi	fondo_pnoa	\N	t	5	f	wms	0	28	t	t	t	2025-01-16 11:19:06.110625	\N	t	f	wms	\N	f	\N
1	1	Ortoimagen PNOA	aicedronesdi	OI_OrthoimageCoverage	\N	t	3	f	wms	11	28	t	t	t	2023-03-20 15:36:33.896626	\N	t	f	wms	https://www.ign.es/wms-inspire/pnoa-ma/leyendas/pnoa-ma.png	f	\N
2	1	Callejero IGN para Orto	aicedronesdi	IGNBaseOrto	\N	t	1	f	wms	0	28	t	t	t	2023-03-20 15:38:39.662639	\N	t	f	wms	https://www.ign.es/wmts/ign-base/leyendas/ignbase_orto.png	f	\N
\.


--
-- TOC entry 5670 (class 0 OID 0)
-- Dependencies: 223
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jobs_id_seq', 2942, true);


--
-- TOC entry 5671 (class 0 OID 0)
-- Dependencies: 225
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 60, true);


--
-- TOC entry 5672 (class 0 OID 0)
-- Dependencies: 230
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permissions_id_seq', 10, true);


--
-- TOC entry 5673 (class 0 OID 0)
-- Dependencies: 232
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, true);


--
-- TOC entry 5674 (class 0 OID 0)
-- Dependencies: 235
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 3, true);


--
-- TOC entry 5675 (class 0 OID 0)
-- Dependencies: 238
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 27, true);


--
-- TOC entry 5676 (class 0 OID 0)
-- Dependencies: 241
-- Name: proyecto_id_seq; Type: SEQUENCE SET; Schema: sch_aicedronesdi; Owner: postgres
--

SELECT pg_catalog.setval('sch_aicedronesdi.proyecto_id_seq', 4, true);


--
-- TOC entry 5677 (class 0 OID 0)
-- Dependencies: 243
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: sch_aicedronesdi; Owner: postgres
--

SELECT pg_catalog.setval('sch_aicedronesdi.tasks_id_seq', 35, true);


--
-- TOC entry 5678 (class 0 OID 0)
-- Dependencies: 244
-- Name: trabajo_id_seq; Type: SEQUENCE SET; Schema: sch_aicedronesdi; Owner: postgres
--

SELECT pg_catalog.setval('sch_aicedronesdi.trabajo_id_seq', 107, true);


--
-- TOC entry 5679 (class 0 OID 0)
-- Dependencies: 245
-- Name: capas_id_seq; Type: SEQUENCE SET; Schema: sch_viewer; Owner: postgres
--

SELECT pg_catalog.setval('sch_viewer.capas_id_seq', 14, true);


--
-- TOC entry 5680 (class 0 OID 0)
-- Dependencies: 247
-- Name: grupo_simbologia_id_seq; Type: SEQUENCE SET; Schema: sch_viewer; Owner: postgres
--

SELECT pg_catalog.setval('sch_viewer.grupo_simbologia_id_seq', 6, true);


--
-- TOC entry 5681 (class 0 OID 0)
-- Dependencies: 248
-- Name: grupos_id_seq; Type: SEQUENCE SET; Schema: sch_viewer; Owner: postgres
--

SELECT pg_catalog.setval('sch_viewer.grupos_id_seq', 1, true);


--
-- TOC entry 5682 (class 0 OID 0)
-- Dependencies: 250
-- Name: simbologia_id_seq; Type: SEQUENCE SET; Schema: sch_viewer; Owner: postgres
--

SELECT pg_catalog.setval('sch_viewer.simbologia_id_seq', 257, true);


--
-- TOC entry 5427 (class 2606 OID 20546)
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- TOC entry 5430 (class 2606 OID 20548)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 5433 (class 2606 OID 20550)
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- TOC entry 5436 (class 2606 OID 20552)
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- TOC entry 5439 (class 2606 OID 20554)
-- Name: permissions permissions_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_guard_name_unique UNIQUE (name, guard_name);


--
-- TOC entry 5441 (class 2606 OID 20556)
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 5443 (class 2606 OID 20558)
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 5445 (class 2606 OID 20560)
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- TOC entry 5448 (class 2606 OID 20562)
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- TOC entry 5450 (class 2606 OID 20564)
-- Name: roles roles_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_guard_name_unique UNIQUE (name, guard_name);


--
-- TOC entry 5452 (class 2606 OID 20566)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 5455 (class 2606 OID 20568)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 5458 (class 2606 OID 20570)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- TOC entry 5460 (class 2606 OID 20572)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 5464 (class 2606 OID 20574)
-- Name: project pk_proyecto; Type: CONSTRAINT; Schema: sch_aicedronesdi; Owner: postgres
--

ALTER TABLE ONLY sch_aicedronesdi.project
    ADD CONSTRAINT pk_proyecto PRIMARY KEY (id);


--
-- TOC entry 5467 (class 2606 OID 20576)
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: sch_aicedronesdi; Owner: postgres
--

ALTER TABLE ONLY sch_aicedronesdi.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- TOC entry 5462 (class 2606 OID 20578)
-- Name: job trabajo_pkey; Type: CONSTRAINT; Schema: sch_aicedronesdi; Owner: postgres
--

ALTER TABLE ONLY sch_aicedronesdi.job
    ADD CONSTRAINT trabajo_pkey PRIMARY KEY (id);


--
-- TOC entry 5469 (class 2606 OID 20584)
-- Name: groups layer_group_pkey; Type: CONSTRAINT; Schema: sch_viewer; Owner: postgres
--

ALTER TABLE ONLY sch_viewer.groups
    ADD CONSTRAINT layer_group_pkey PRIMARY KEY (id);


--
-- TOC entry 5471 (class 2606 OID 20586)
-- Name: layers layer_pkey; Type: CONSTRAINT; Schema: sch_viewer; Owner: postgres
--

ALTER TABLE ONLY sch_viewer.layers
    ADD CONSTRAINT layer_pkey PRIMARY KEY (id);


--
-- TOC entry 5428 (class 1259 OID 20597)
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- TOC entry 5431 (class 1259 OID 20598)
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- TOC entry 5434 (class 1259 OID 20599)
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- TOC entry 5437 (class 1259 OID 20600)
-- Name: password_resets_email_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX password_resets_email_index ON public.password_resets USING btree (email);


--
-- TOC entry 5446 (class 1259 OID 20601)
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- TOC entry 5453 (class 1259 OID 20602)
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- TOC entry 5456 (class 1259 OID 20603)
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- TOC entry 5465 (class 1259 OID 20604)
-- Name: proyecto_geom_idx; Type: INDEX; Schema: sch_aicedronesdi; Owner: postgres
--

CREATE INDEX proyecto_geom_idx ON sch_aicedronesdi.project USING gist (geom);


--
-- TOC entry 5472 (class 2606 OID 20685)
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- TOC entry 5473 (class 2606 OID 20690)
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 5474 (class 2606 OID 20695)
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- TOC entry 5475 (class 2606 OID 20700)
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 5477 (class 2606 OID 20705)
-- Name: tasks fk_tasks_proyecto; Type: FK CONSTRAINT; Schema: sch_aicedronesdi; Owner: postgres
--

ALTER TABLE ONLY sch_aicedronesdi.tasks
    ADD CONSTRAINT fk_tasks_proyecto FOREIGN KEY (project_id) REFERENCES sch_aicedronesdi.project(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 5476 (class 2606 OID 20710)
-- Name: job fk_trabajo_proyecto; Type: FK CONSTRAINT; Schema: sch_aicedronesdi; Owner: postgres
--

ALTER TABLE ONLY sch_aicedronesdi.job
    ADD CONSTRAINT fk_trabajo_proyecto FOREIGN KEY (id_proyecto) REFERENCES sch_aicedronesdi.project(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- TOC entry 5478 (class 2606 OID 20715)
-- Name: layers fk_layer_layer_group; Type: FK CONSTRAINT; Schema: sch_viewer; Owner: postgres
--

ALTER TABLE ONLY sch_viewer.layers
    ADD CONSTRAINT fk_layer_layer_group FOREIGN KEY (id_grupo) REFERENCES sch_viewer.groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 5657 (class 0 OID 0)
-- Dependencies: 9
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2025-02-07 13:02:02 UTC

--
-- PostgreSQL database dump complete
--

